from shodan import Shodan
import shodan
import discord
from dotenv import load_dotenv
load_dotenv(dotenv_path="config")
default_intents = discord.Intents.default()
client = discord.Client(intents=default_intents)

default_intents.members = True



@client.event
async def on_ready():
    print("Le bot est prêt !")
    if message.content ==
api=shodan.Shodan(API_KEY)
FACETS=[("port",361), ]
api.count("200, 300",facets=FACETS)
await message.channel.send("!range 149.62.158.57 63")


client.run("OTYwMTg4NjQ3ODgwMTUxMTgz.YkmzXQ.1JEYkP-p0fyucdGqEfOfs53kViY")


